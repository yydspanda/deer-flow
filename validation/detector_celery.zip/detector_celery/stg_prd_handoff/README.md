# sec_know_model：STG / PRD Detector 配置接入

本目录随外层 `detector_celery` 文件夹一起传入内网，面向源码准备和部署评审。依据是此前提供的 Linux / PKS 部署快照；实际内网文件若有变化，以当前部署文件为准。Collector 地址尚待运维确认，因此模板中的 STG / PRD 地址留空。空地址不能启动探针 worker。

本次沿用已有 `prepare.py` 和 `scripts/detector_worker.py`，配置准备不启动服务、不提交告警、不修改厂商 SDK 的 Python 源码。DEV 当前的网络问题作为单独事项保留。

## 文件用途

| 文件 | 用途 |
| --- | --- |
| `profiles.example.json` | 三套环境的应用名和 Collector 模板；合并到项目已有 `config/detector/profiles.json` |
| `detector-minimal.ini.fragment` | 合并到 SDK 的现有 `[newrelic]` 段，关闭 AI 详细采集 |
| `celery_task.conf.patch` | 根据现有部署快照生成的三条启动命令差异，供评审；实际候选配置由 r2 工具从内网当前文件生成 |

配套工具已放在外层 `detector_celery` 中，沿用 23 号 r2 的原版本。本目录不包含私有 SDK、真实环境配置、业务数据或完整 Supervisor 配置。

## 0. 解压文件夹并准备文件

将整个 `detector_celery` 文件夹压缩后传入内网，解压到用户主目录，得到：

```text
~/detector_celery/prepare.py
~/detector_celery/files/
~/detector_celery/stg_prd_handoff/README.md
```

先生成候选配置并补齐项目中的 wrapper / profiles 文件。若已执行外层 README 中的命令，可直接从第 1 步继续：

```bash
"$HOME/sec_know_model/.venv/bin/python" "$HOME/detector_celery/prepare.py" \
  --root "$HOME/sec_know_model" --target supervisor
```

若在其他构建机执行，替换为该项目的 Python 和实际源码路径。该操作保留原 Supervisor 文件及已有 `profiles.json`；缺少 profiles 时才从模板创建。然后按下文填写环境配置。工具包不包含厂商 SDK，STG / PRD 仍需维护方确认的 Linux SDK。

## 1. 填写环境配置

在内网项目 `config/detector/profiles.json` 中更新 `stg`、`prd` 两个对象，保留已有 LOCAL 配置：

| 环境 | 应用名 | Collector |
| --- | --- | --- |
| STG | `sec-know-celery-stg` | 运维确认后填写 |
| PRD | `sec-know-celery-prd` | 运维确认后填写 |

Collector 填主机名或 IPv4，不带协议、路径或端口。此处填写探针上报地址，不填写业务服务域名或 WiseAPM 网页地址。STG / PRD 的业务服务域名分别作为运维定位部署的线索：

- STG：`sec-model-python-faq-robot.default.sfe-serving-cqb-stg.paic.com.cn`
- PRD：`sec-model-python-faq-robot.default.sfe-serving-szf-new.paic.com.cn`

此前手册中的 CQB STG 候选为 `cqtransfer-stg.paic.com.cn`（VIP `30.184.9.82`）；这是历史候选，须确认当前仍适用。PRD 须按实际机房和网络区域选择，不能从业务域名直接推定 Collector。网络来源使用 Celery 实际 Pod / 节点 / NAT 出口，由运维核验到所选 Collector 的 TCP 9994、UDP 9995/9996。

## 2. 设置最小采集

STG / PRD 使用 Detector 维护方确认的 Linux SDK。在该 SDK 的 `detector.ini` 已有 `[newrelic]` 段中设置：

```ini
ai_monitoring.enabled = false
ai_monitoring.record_content.enabled = false
```

已有同名项修改原值，没有的项在该段内新增。保留其他厂商必需配置。配置片段不能直接覆盖整个 `detector.ini`。

`detector_worker.py` 从此 INI 复制设置，再写入对应环境的应用名、Collector、实例标识和 stdout 日志设置。真正使用的 INI 位于 `nas/data/detector/{profile}/`，每次启动会重新生成，因此编辑源 INI。

这两项关闭主要的 AI 专项采集，Celery 基础任务追踪仍保留。不能据此保证每一份报文小于 9 KiB，也不能将 Mac 的 UDP 发送限制直接推定为 Linux 的限制。

## 3. 审核 Supervisor 候选

第 0 步已从内网当前 `config/celery_task.conf` 生成 `config/celery_task.detector.conf`。在项目目录查看差异：

```bash
diff -u config/celery_task.conf config/celery_task.detector.conf
```

有差异时 `diff` 返回 1，属于正常结果。

审核差异应仅涉及以下三个 worker 的命令前缀：

| worker | 精确队列 | 原有并发（快照） | 新命令前缀 |
| --- | --- | --- | --- |
| v32 | `DeepSeek_V32_queue` | 6 | `python scripts/detector_worker.py v32 --` |
| v4 | `DeepSeek_V4_Flash_My_queue` | 6 | `python scripts/detector_worker.py v4 --` |
| pub | `Pub_DeepSeek_V4_Flash_queue` | 20 | `python scripts/detector_worker.py pub --` |

前缀后保留原 `celery` 命令的全部参数，包括队列、并发、worker 名称。Linux 原配置使用默认 prefork，不能复制 Mac 的 `-P threads` 参数。Supervisor 的 `%%h`、日志和进程组停止设置继续按原文件处理。

## 4. 将配置带入镜像

准备好并审查候选后，在待构建的源码副本中应用：

```bash
"$HOME/sec_know_model/.venv/bin/python" "$HOME/detector_celery/prepare.py" \
  --root "$HOME/sec_know_model" --target supervisor --apply-supervisor
```

该命令先备份 `config/celery_task.conf`，再替换配置；不启动或重启服务。保留输出的备份路径。

现有 Dockerfile 使用 `COPY ./config/celery_task.conf /etc/supervisor/conf.d/`。沿现有构建流程，把更新后的配置、`scripts/detector_worker.py`、私有 `config/detector/profiles.json` 和维护方确认的 SDK 一起放入构建上下文。它们位于 Git 忽略路径时，CI 不会自动从仓库取得，须通过现有私有构建输入提供，并核对 `.dockerignore`。

默认 SDK 路径是 `/usr/src/app/detector-python-agent-v3.2.3`；不同路径通过 `DETECTOR_AGENT_HOME` 设置。运行用户需要读取 SDK / profiles，并能写入 `/usr/src/app/nas/data/detector`，也可通过 `DETECTOR_RUNTIME_DIR` 指定实际可写目录。

部署环境变量使用：

- STG：`env_profile=stg`
- PRD：`env_profile=prd`

使用原业务环境选择器，不在代码里切换 STG / PRD。原 `run.sh` 的分支按小写环境值判断。`local_run.detector.sh` 是 LOCAL 入口，不用于这两个环境。

## 5. 上线前做配置检查

在已包含上述文件的目标构建 / 验证环境中，用目标业务 Python 检查。以下是三条 STG 检查命令；PRD 分别将 `stg` 换成 `prd`：

```bash
env_profile=stg python scripts/detector_worker.py v32 --check -- -A tasks.task.app worker -c 6 --loglevel=info -Q DeepSeek_V32_queue -n DeepSeek_V32_worker
env_profile=stg python scripts/detector_worker.py v4 --check -- -A tasks.task.app worker -c 6 --loglevel=info -Q DeepSeek_V4_Flash_My_queue -n DeepSeek_V4_Flash_My_worker
env_profile=stg python scripts/detector_worker.py pub --check -- -A tasks.task.app worker -c 20 --loglevel=info -Q Pub_DeepSeek_V4_Flash_queue -n Pub_DeepSeek_V4_Flash_worker
```

输出应为 `mode: check_only`，环境、Collector、应用名、SDK 路径和三个基础 Agent ID 正确。该检查不导入 SDK / 业务代码，不联网，不生成运行时 INI，不启动 worker；成功只证明静态配置通过。

不要通过手工运行 `run.sh` 检查配置：已提供的快照入口包含业务初始化、队列清理及 STG 测试任务注入。启动与发布沿用项目的原有流程。

## 6. STG 验收及 PRD 配置准备

先在 STG 的既有验证流程中核对初始化、当前实例、任务执行耗时和异常记录。仅出现 `Detector Python Initialize successfully` 不代表 UDP 指标和任务链路都到达平台。

**现有 SDK 有一个已经记录的 prefork 多进程标识风险：**同一 worker 的子进程会继承启动标识和序号，可能出现事务 ID / 元数据标识碰撞。三个 wrapper ID 只区分三组 worker，不等于已隔离其全部子进程。请 Detector 维护方提供受支持的 SDK 或解决方案，并在 STG 验证不同子进程的记录归属和回收行为；这不需要使用者修改 SDK，也不能通过改成 Mac 的 threads 池绕过。

PRD 的配置和构建输入可以同步准备；生产发布使用完成 STG 验收的 SDK / 配置组合。当前交付状态为“配置模板与启动差异已准备，地址确认和内网运行验收待完成”。

## 7. 回退

通过既有发布流程恢复原镜像，或恢复准备工具生成的 `celery_task.conf` 备份并重新构建发布。回退监控接入不需要清库、清队列或重建业务数据。
