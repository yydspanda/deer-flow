# 本地检查记录

日期：2026-09-28。以下均为外网离线准备检查，不是内网运行验收。

- 23 号 r2 原包从留存副本恢复，SHA-256 与原校验文件一致；ZIP CRC 检查通过。
- 原包 SHA-256：`d6d8f6945a46dbaaa550c808fb6c5f020b171214298e8ec634404962d01a2a42`。
- 已整理为单个 `detector_celery` 文件夹；prepare、wrapper、环境模板及两份测试与 r2 原包逐字节一致。
- 在临时目录解压整包后，运行随包的 38 项离线测试，全部通过。
- 解压后的准备工具冒烟检查通过：`--check` 无写入；普通准备生成 wrapper、profiles 和候选配置，保留原 Supervisor 文件。
- profiles JSON 可解析；STG / PRD Collector 保持空值，等待运维确认。
- 最小采集 INI 片段可解析，两项 AI 配置均为 false。
- 使用现有 r2 prepare.py 从已有部署快照渲染 Supervisor 候选。
- 候选与原配置恰好三行不同，仅替换目标 Celery 命令前缀。
- 三个目标队列、6 / 6 / 20 并发及 %%h 保留；未加入 -P threads。
- 现有 prepare 测试通过：13 项。
- 现有 detector_worker 测试通过：25 项。
- 本次配置包不包含私有 SDK、实际 profiles、完整业务 Supervisor 文件或业务日志。

尚未完成：STG / PRD Collector 确认、镜像内文件与权限检查、内网连通性、原生 Linux prefork 验收，以及平台任务链路可见性。
