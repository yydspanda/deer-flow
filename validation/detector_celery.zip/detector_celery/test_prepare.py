"""Offline preparation tests; fixtures never launch Celery or import the application."""

from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

SPEC = importlib.util.spec_from_file_location(
    "detector_prepare_under_test", Path(__file__).parent / "prepare.py"
)
assert SPEC is not None and SPEC.loader is not None
prepare = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(prepare)


MAC_SOURCE = (
    "# existing launcher\n"
    ". ./.venv/bin/activate\n"
    "trap 'kill $(jobs -p) 2>/dev/null; wait' SIGINT SIGTERM\n"
    "celery -A tasks.task.app worker -c 1 -P threads -Q other -n untouched &\n"
    "celery -A tasks.task.app worker  -c 2 --loglevel=info -P threads -Q DeepSeek_V32_queue -n v32 & # keep me\n"
    "\tcelery -A tasks.task.app worker -c 2 -P threads -Q 'DeepSeek_V4_Flash_My_queue' -n v4 &\n"
    "celery -A tasks.task.app worker -c 2 -P threads --queues=Pub_DeepSeek_V4_Flash_queue -n pub &\n"
    "celery -A tasks.task.app beat --loglevel=info &\n"
    "wait"
)

SUPERVISOR_SOURCE = (
    "# original deployment\n"
    "[program:other]\ncommand=celery -A tasks.task.app worker -Q other\n"
    'environment=EXAMPLE="preserve this value"\n'
    "[program:DeepSeek_V32_worker] # keep comment\n"
    "command=celery -A tasks.task.app worker -c 6 --loglevel=info -Q DeepSeek_V32_queue -n DeepSeek_V32_worker_%%h\n"
    "directory=/usr/src/app\nstopasgroup=true\n"
    "[program:DeepSeek_V4_Flash_My_worker]\n"
    "command = celery -A tasks.task.app worker -c 6 -Q DeepSeek_V4_Flash_My_queue -n DeepSeek_V4_Flash_My_worker_%%h\n"
    "directory=/usr/src/app\nstdout_logfile=%(ENV_CELERY_LOG_PATH)s/supervisor_process.log\n"
    "[program:Pub_DeepSeek_V4_Flash_worker]\n"
    "command=celery -A tasks.task.app worker -c 20 -Q Pub_DeepSeek_V4_Flash_queue -n Pub_DeepSeek_V4_Flash_worker_%%h\n"
    "directory=/usr/src/app\nstdout_logfile_maxbytes=10MB\n"
)


class PrepareTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="detector prepare ")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / "project with spaces"
        self.root.mkdir()
        (self.root / "config").mkdir()
        (self.root / "local_run.sh").write_bytes(MAC_SOURCE.encode())
        (self.root / "config/celery_task.conf").write_bytes(SUPERVISOR_SOURCE.encode())
        self.package = Path(self.temp.name) / "package"
        (self.package / "files/scripts").mkdir(parents=True)
        (self.package / "files/config/detector").mkdir(parents=True)
        self.wrapper = self.package / "files/scripts/detector_worker.py"
        self.wrapper.write_text(
            "raise AssertionError('must never be executed')\n", encoding="utf-8"
        )
        self.example = self.package / "files/config/detector/profiles.example.json"
        self.example.write_text(
            json.dumps({"local": {}, "stg": {}, "prd": {}}), encoding="utf-8"
        )

    def run_prepare(self, target="mac", **kwargs):
        return prepare.prepare(self.root, target, package_dir=self.package, **kwargs)

    def snapshot(self):
        return {
            p.relative_to(self.root): p.read_bytes()
            for p in self.root.rglob("*")
            if p.is_file()
        }

    def test_mac_preserves_arguments_other_lines_and_uses_dynamic_root(self):
        self.run_prepare()
        generated = (self.root / "local_run.detector.sh").read_text(encoding="utf-8")
        expected_body = MAC_SOURCE
        replacements = (
            (
                "celery -A tasks.task.app worker  -c 2",
                '"$ROOT/.venv/bin/python" "$ROOT/scripts/detector_worker.py" v32 -- -A tasks.task.app worker  -c 2',
            ),
            (
                "\tcelery -A tasks.task.app worker -c 2",
                '\t"$ROOT/.venv/bin/python" "$ROOT/scripts/detector_worker.py" v4 -- -A tasks.task.app worker -c 2',
            ),
            (
                "celery -A tasks.task.app worker -c 2 -P threads --queues",
                '"$ROOT/.venv/bin/python" "$ROOT/scripts/detector_worker.py" pub -- -A tasks.task.app worker -c 2 -P threads --queues',
            ),
        )
        for original, replacement in replacements:
            expected_body = expected_body.replace(original, replacement)
        self.assertTrue(generated.endswith(expected_body))
        self.assertIn("${BASH_SOURCE[0]}", generated)
        self.assertIn("local|LOCAL)", generated)
        self.assertIn("export env_profile=local", generated)
        self.assertNotIn(str(self.root), generated)
        self.assertEqual((self.root / "local_run.sh").read_bytes(), MAC_SOURCE.encode())
        subprocess.run(
            ["bash", "-n", str(self.root / "local_run.detector.sh")],
            check=True,
            capture_output=True,
        )

    def test_mac_rejects_other_environment_before_source_commands(self):
        self.run_prepare()

        result = subprocess.run(
            ["bash", str(self.root / "local_run.detector.sh")],
            env={**os.environ, "env_profile": "stg"},
            capture_output=True,
            text=True,
        )
        self.assertEqual(result.returncode, 2)
        self.assertIn("local or LOCAL", result.stderr)
        self.assertNotIn("activate", result.stderr)

    def test_mac_pins_local_even_if_original_script_attempts_override(self):
        source = (
            "export env_profile=stg\n"
            + "\n".join(
                f"celery -A tasks.task.app worker -c 2 -P threads -Q {queue} &"
                for queue in prepare.QUEUE_WORKERS
            )
            + "\nwait\n"
        )
        (self.root / "local_run.sh").write_text(source, encoding="utf-8")
        fake_python = self.root / ".venv/bin/python"
        fake_python.parent.mkdir(parents=True)
        fake_python.write_text(
            '#!/bin/sh\nprintf "%s\\n" "$env_profile" >> "$DETECTOR_TEST_REPORT"\n',
            encoding="utf-8",
        )
        fake_python.chmod(0o755)
        report = self.root / "worker-environments.txt"
        self.run_prepare()
        result = subprocess.run(
            ["bash", str(self.root / "local_run.detector.sh")],
            env={
                **os.environ,
                "env_profile": "LOCAL",
                "DETECTOR_TEST_REPORT": str(report),
            },
            capture_output=True,
            text=True,
        )
        self.assertEqual(result.returncode, 0)
        self.assertEqual(report.read_text(encoding="utf-8").splitlines(), ["local"] * 3)
        self.assertIn("readonly", result.stderr)

    def test_supervisor_stages_without_changing_original(self):
        self.run_prepare("supervisor")
        self.assertEqual(
            (self.root / "config/celery_task.conf").read_bytes(),
            SUPERVISOR_SOURCE.encode(),
        )
        generated = (self.root / "config/celery_task.detector.conf").read_text(
            encoding="utf-8"
        )
        expected = SUPERVISOR_SOURCE
        for marker, worker in (
            ("worker -c 6 --loglevel", "v32"),
            ("worker -c 6 -Q", "v4"),
            ("worker -c 20 -Q", "pub"),
        ):
            original = f"celery -A tasks.task.app {marker}"
            expected = expected.replace(
                original,
                f"python scripts/detector_worker.py {worker} -- -A tasks.task.app {marker}",
            )
        self.assertEqual(generated, expected)
        self.assertEqual(generated.count("%%h"), 3)
        self.assertNotIn("-P threads", generated)
        self.assertFalse(list((self.root / "config").glob("*.bak.*")))

    def test_apply_supervisor_backs_up_and_can_be_repeated(self):
        self.run_prepare("supervisor", apply_supervisor=True)
        backups = list((self.root / "config").glob("celery_task.conf.bak.*"))
        self.assertEqual(len(backups), 1)
        self.assertEqual(backups[0].read_bytes(), SUPERVISOR_SOURCE.encode())
        applied = (self.root / "config/celery_task.conf").read_bytes()
        self.run_prepare("supervisor", apply_supervisor=True)
        self.assertEqual((self.root / "config/celery_task.conf").read_bytes(), applied)
        self.assertEqual(applied.count(b"scripts/detector_worker.py"), 3)

    def test_existing_profiles_are_never_overwritten_and_ignores_are_idempotent(self):
        (self.root / "config/detector").mkdir()
        profile = self.root / "config/detector/profiles.json"
        profile.write_bytes(b'{"private": "keep existing bytes"}\n')
        (self.root / ".gitignore").write_bytes(b"existing-entry")
        self.run_prepare()
        first = self.snapshot()
        self.run_prepare()
        self.assertEqual(self.snapshot(), first)
        self.assertEqual(profile.read_bytes(), b'{"private": "keep existing bytes"}\n')
        ignore = (self.root / ".gitignore").read_text(encoding="utf-8")
        for entry in prepare.IGNORE_ENTRIES:
            self.assertEqual(ignore.splitlines().count(entry), 1)

    def test_new_profile_is_private_and_wrapper_is_installed_without_execution(self):
        self.run_prepare()
        self.assertEqual(
            (self.root / "scripts/detector_worker.py").read_bytes(),
            self.wrapper.read_bytes(),
        )
        self.assertEqual(
            (self.root / "config/detector/profiles.example.json").read_bytes(),
            self.example.read_bytes(),
        )
        profile = self.root / "config/detector/profiles.json"
        self.assertEqual(profile.read_bytes(), self.example.read_bytes())
        self.assertEqual(profile.stat().st_mode & 0o777, 0o600)

    def test_check_does_not_write_even_with_apply(self):
        before = self.snapshot()
        self.run_prepare("supervisor", check=True, apply_supervisor=True)
        self.assertEqual(self.snapshot(), before)

    def test_missing_and_duplicate_targets_fail_before_writing(self):
        for source in (
            MAC_SOURCE.replace("-Q DeepSeek_V32_queue", "-Q not-target"),
            MAC_SOURCE + "\ncelery -A tasks.task.app worker -Q DeepSeek_V32_queue &\n",
        ):
            with self.subTest(source_count=source.count("DeepSeek_V32_queue")):
                (self.root / "local_run.sh").write_bytes(source.encode())
                before = self.snapshot()
                with self.assertRaises(ValueError):
                    self.run_prepare()
                self.assertEqual(self.snapshot(), before)

    def test_complex_target_shell_and_multiple_queues_fail_before_writing(self):
        for source in (
            MAC_SOURCE.replace(
                "celery -A tasks.task.app worker  -c 2",
                "env EXAMPLE=value celery -A tasks.task.app worker  -c 2",
            ),
            MAC_SOURCE.replace("-Q DeepSeek_V32_queue", "-Q DeepSeek_V32_queue,other"),
            MAC_SOURCE.replace(" & # keep me", " && echo done # keep me"),
        ):
            with self.subTest():
                (self.root / "local_run.sh").write_bytes(source.encode())
                before = self.snapshot()
                with self.assertRaises(ValueError):
                    self.run_prepare()
                self.assertEqual(self.snapshot(), before)

    def test_invalid_package_fails_before_writing(self):
        self.example.write_text("not json", encoding="utf-8")
        before = self.snapshot()
        with self.assertRaises(ValueError):
            self.run_prepare()
        self.assertEqual(self.snapshot(), before)

    def test_comments_and_crlf_are_preserved(self):
        source = SUPERVISOR_SOURCE.replace("\n", "\r\n")
        (self.root / "config/celery_task.conf").write_bytes(source.encode())
        self.run_prepare("supervisor")
        generated = (self.root / "config/celery_task.detector.conf").read_bytes()
        self.assertEqual(generated.count(b"\r\n"), source.count("\r\n"))
        self.assertIn(b"# keep comment\r\n", generated)

    def test_wrong_apply_target_and_mismatched_wrapper_key_are_rejected(self):
        before = self.snapshot()
        with self.assertRaises(ValueError):
            self.run_prepare("mac", apply_supervisor=True)
        self.assertEqual(self.snapshot(), before)
        source = SUPERVISOR_SOURCE.replace(
            "command=celery -A tasks.task.app worker -c 6 --loglevel",
            "command=python scripts/detector_worker.py pub -- -A tasks.task.app worker -c 6 --loglevel",
        )
        (self.root / "config/celery_task.conf").write_bytes(source.encode())
        before = self.snapshot()
        with self.assertRaises(ValueError):
            self.run_prepare("supervisor")
        self.assertEqual(self.snapshot(), before)


if __name__ == "__main__":
    unittest.main()
