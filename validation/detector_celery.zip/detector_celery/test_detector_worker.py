"""Offline launcher checks; fake SDK/Celery processes never import business code."""

from __future__ import annotations

import configparser
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest
from unittest import mock


SOURCE = Path(__file__).parent / "files" / "scripts" / "detector_worker.py"
SPEC = importlib.util.spec_from_file_location("detector_worker_under_test", SOURCE)
assert SPEC is not None and SPEC.loader is not None
launcher = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = launcher
SPEC.loader.exec_module(launcher)

QUEUES = {
    "v32": "DeepSeek_V32_queue",
    "v4": "DeepSeek_V4_Flash_My_queue",
    "pub": "Pub_DeepSeek_V4_Flash_queue",
}
PROFILES = {
    "local": {
        "app_name": "sec-know-celery-dev",
        "collector_ip": "30.171.36.66",
    },
    "stg": {"app_name": "sec-know-celery-stg", "collector_ip": ""},
    "prd": {"app_name": "sec-know-celery-prd", "collector_ip": ""},
}
BASE_INI = """# Synthetic fixture, never real credentials.
[newrelic]
app_name = template-app
agent_id = template-agent
collector_ip = 192.0.2.9
log_file = /tmp/old-detector.log
log_level = debug
license_key = fixture-private-license-100%only
monitor_mode = true
transaction_tracer.enabled = true

[newrelic:production]
app_name = inherited-production-app
collector_ip = 192.0.2.90

[custom]
unicode_value = 示例
literal_percent = %(unchanged)s
"""
POLLUTED_VARIABLES = (
    "NEW_RELIC_ENVIRONMENT",
    "NEW_RELIC_APP_NAME",
    "DETECTOR_AGENT_ID",
    "DETECTOR_COLLECTOR_IP",
    "NEW_RELIC_LOG",
    "NEW_RELIC_LOG_LEVEL",
)


class DetectorWorkerTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="detector test ")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name) / "business root with spaces"
        self.sdk = self.root / "detector-python-agent-v3.2.3"
        self.sdk.mkdir(parents=True)
        (self.sdk / "newrelic").mkdir()
        (self.sdk / "newrelic" / "__init__.py").write_text(
            "raise AssertionError('SDK must not be imported by wrapper')\n",
            encoding="utf-8",
        )
        self.base_ini = self.sdk / "detector.ini"
        self.base_ini.write_text(BASE_INI, encoding="utf-8")
        (self.sdk / "detector-admin").write_text("# fake SDK entry\n", encoding="utf-8")
        self.profile_file = self.root / "config" / "detector" / "profiles.json"
        self.profile_file.parent.mkdir(parents=True)
        self.profile_file.write_text(json.dumps(PROFILES), encoding="utf-8")
        self.environ = {"env_profile": "local", "DETECTOR_INSTANCE_ID": "fixture-host"}

    @staticmethod
    def args(worker="v32", queue_flag="-Q"):
        return [
            "-A",
            "fake_business.celery_app",
            "worker",
            "-Q" if queue_flag == "-Q" else queue_flag,
            QUEUES[worker],
            "--concurrency=2",
            "-n",
            "fixture@%%h",
            "--loglevel=info",
        ]

    def build(self, worker="v32", *, args=None, environ=None):
        return launcher.build_launch(
            self.root,
            worker,
            self.args(worker) if args is None else args,
            self.environ if environ is None else environ,
        )

    def test_build_preserves_template_values_arguments_and_does_not_write(self):
        args = self.args()
        env_before = self.environ.copy()
        files_before = set(self.root.rglob("*"))
        with (
            mock.patch(
                "socket.create_connection", side_effect=AssertionError("network")
            ),
            mock.patch("socket.getaddrinfo", side_effect=AssertionError("DNS lookup")),
        ):
            launch = self.build(args=args)
        self.assertEqual(set(self.root.rglob("*")), files_before)
        self.assertEqual(self.environ, env_before)
        self.assertEqual(self.base_ini.read_text(encoding="utf-8"), BASE_INI)
        self.assertEqual(launch.profile, "local")
        self.assertEqual(launch.worker, "v32")
        self.assertEqual(launch.sdk, self.sdk)
        self.assertIsInstance(launch.settings, configparser.ConfigParser)
        self.assertEqual(launch.settings["newrelic"]["log_file"], "stdout")
        self.assertEqual(launch.settings["newrelic"]["log_level"], "info")
        self.assertEqual(launch.settings["newrelic"]["app_name"], "sec-know-celery-dev")
        self.assertEqual(launch.settings["newrelic"]["collector_ip"], "30.171.36.66")
        self.assertEqual(launch.settings["newrelic"]["agent_id"], launch.agent_id)
        self.assertEqual(
            launch.settings["newrelic"]["license_key"],
            "fixture-private-license-100%only",
        )
        self.assertEqual(
            launch.settings["newrelic"]["transaction_tracer.enabled"], "true"
        )
        self.assertEqual(launch.settings["custom"]["unicode_value"], "示例")
        self.assertEqual(launch.settings["custom"]["literal_percent"], "%(unchanged)s")
        self.assertEqual(
            launch.settings["newrelic:production"]["collector_ip"], "192.0.2.90"
        )
        self.assertEqual(
            launch.command,
            [
                sys.executable,
                str(self.sdk / "detector-admin"),
                "run-program",
                sys.executable,
                "-m",
                "celery",
                *args,
            ],
        )
        self.assertEqual(args, self.args())
        self.assertEqual(launch.env["NEW_RELIC_CONFIG_FILE"], str(launch.config_path))
        self.assertEqual(
            launch.config_path,
            self.root
            / "nas"
            / "data"
            / "detector"
            / "local"
            / f"{launch.agent_id}.ini",
        )

    def test_host_overrides_win_then_inherited_agent_selectors_are_removed(self):
        env = {
            **self.environ,
            "NEW_RELIC_APP_NAME": "explicit-local-app",
            "DETECTOR_COLLECTOR_IP": "192.0.2.20",
            "NEW_RELIC_ENVIRONMENT": "production",
            "DETECTOR_AGENT_ID": "shared-hardcoded-id",
            "NEW_RELIC_LOG": "/tmp/unwanted-file.log",
            "NEW_RELIC_LOG_LEVEL": "debug",
            "NEW_RELIC_CONFIG_FILE": "/tmp/unrelated.ini",
            "BUSINESS_SETTING": "preserve-me",
            "PATH": "/fixture/bin",
        }
        untouched = env.copy()
        launch = self.build(environ=env)
        self.assertEqual(env, untouched)
        self.assertEqual(launch.settings["newrelic"]["app_name"], "explicit-local-app")
        self.assertEqual(launch.settings["newrelic"]["collector_ip"], "192.0.2.20")
        self.assertNotEqual(launch.agent_id, "shared-hardcoded-id")
        for variable in POLLUTED_VARIABLES:
            self.assertNotIn(variable, launch.env)
        self.assertEqual(launch.env["BUSINESS_SETTING"], "preserve-me")
        self.assertEqual(launch.env["PATH"], "/fixture/bin")
        self.assertEqual(launch.env["env_profile"], "local")

    def test_enabled_operator_modes_are_rejected_without_writing_or_mutating_env(self):
        before = set(self.root.rglob("*"))
        for variable in (
            "NEW_RELIC_K8S_OPERATOR_ENABLED",
            "NEW_RELIC_AZURE_OPERATOR_ENABLED",
        ):
            for value in ("on", "ON", "true", "True", "1"):
                with self.subTest(variable=variable, value=value):
                    env = {**self.environ, variable: value}
                    original = env.copy()
                    with self.assertRaisesRegex(ValueError, variable):
                        self.build(environ=env)
                    self.assertEqual(env, original)
                    self.assertEqual(set(self.root.rglob("*")), before)

    def test_disabled_operator_values_match_vendor_semantics_and_are_preserved(self):
        for value in ("off", "false", "0", "", "yes", " true ", " ON "):
            with self.subTest(value=value):
                env = {
                    **self.environ,
                    "env_profile": "LOCAL",
                    "NEW_RELIC_K8S_OPERATOR_ENABLED": value,
                    "NEW_RELIC_AZURE_OPERATOR_ENABLED": value,
                }
                launch = self.build(environ=env)
                for variable in (
                    "NEW_RELIC_K8S_OPERATOR_ENABLED",
                    "NEW_RELIC_AZURE_OPERATOR_ENABLED",
                ):
                    self.assertEqual(launch.env[variable], value)
                self.assertEqual(launch.env["env_profile"], "LOCAL")
                self.assertEqual(launch.command[6:], self.args())

    def test_inherited_selected_sdk_bootstrap_is_rejected_before_writing(self):
        bootstrap = self.sdk / "newrelic/bootstrap"
        bootstrap.mkdir()
        alias = self.root / "bootstrap alias"
        alias.symlink_to(bootstrap, target_is_directory=True)
        before = set(self.root.rglob("*"))
        for entry in (
            str(bootstrap),
            str(bootstrap) + "/",
            str(bootstrap.relative_to(self.root)),
            str(alias),
        ):
            for path in (
                entry,
                os.pathsep.join(("/example/other", entry, "/example/last")),
            ):
                with self.subTest(entry=entry, path=path):
                    env = {**self.environ, "PYTHONPATH": path}
                    original = env.copy()
                    with self.assertRaisesRegex(ValueError, "PYTHONPATH"):
                        self.build(environ=env)
                    self.assertEqual(env, original)
                    self.assertEqual(set(self.root.rglob("*")), before)

    def test_unrelated_pythonpath_is_preserved_exactly(self):
        path = os.pathsep.join(
            ("", "/example/other", str(self.sdk / "newrelic/bootstrap-tools"), ".")
        )
        launch = self.build(environ={**self.environ, "PYTHONPATH": path})
        self.assertEqual(launch.env["PYTHONPATH"], path)

    def test_bootstrap_guard_uses_sdk_override(self):
        sdk = self.root / "alternate sdk"
        self.sdk.rename(sdk)
        env = {
            **self.environ,
            "DETECTOR_AGENT_HOME": "alternate sdk",
            "PYTHONPATH": str(sdk / "newrelic/bootstrap"),
        }
        with self.assertRaisesRegex(ValueError, "PYTHONPATH"):
            self.build(environ=env)

    def test_profile_is_required_and_rejects_unknown_or_padded_values(self):
        for profile in (None, "", "dev", "production", " local", "local\n"):
            with self.subTest(profile=profile):
                env = self.environ.copy()
                if profile is None:
                    del env["env_profile"]
                else:
                    env["env_profile"] = profile
                with self.assertRaises(ValueError):
                    self.build(environ=env)

    def test_environment_case_matches_root_config_and_preserves_business_value(self):
        profiles = json.loads(self.profile_file.read_text(encoding="utf-8"))
        profiles["stg"]["collector_ip"] = "192.0.2.30"
        profiles["prd"]["collector_ip"] = "192.0.2.40"
        self.profile_file.write_text(json.dumps(profiles), encoding="utf-8")
        for profile in ("local", "stg", "prd"):
            baseline = self.build(environ={**self.environ, "env_profile": profile})
            for value in (profile, profile.upper(), profile.title()):
                with self.subTest(value=value):
                    launch = self.build(environ={**self.environ, "env_profile": value})
                    self.assertEqual(launch.profile.upper(), value.upper())
                    self.assertEqual(launch.env["env_profile"], value)
                    self.assertEqual(launch.agent_id, baseline.agent_id)
                    self.assertEqual(launch.config_path, baseline.config_path)
                    self.assertEqual(
                        dict(launch.settings["newrelic"]),
                        dict(baseline.settings["newrelic"]),
                    )

    def test_empty_stg_and_prd_collectors_fail_closed(self):
        for profile in ("stg", "STG", "prd", "PRD"):
            with self.subTest(profile=profile), self.assertRaises(ValueError):
                self.build(environ={**self.environ, "env_profile": profile})

    def test_configured_stg_and_prd_use_their_profile(self):
        profiles = json.loads(self.profile_file.read_text(encoding="utf-8"))
        for profile, address in (("stg", "192.0.2.30"), ("prd", "192.0.2.40")):
            profiles[profile]["collector_ip"] = address
        self.profile_file.write_text(json.dumps(profiles), encoding="utf-8")
        for profile in ("stg", "prd"):
            with self.subTest(profile=profile):
                launch = self.build(environ={**self.environ, "env_profile": profile})
                self.assertEqual(
                    launch.settings["newrelic"]["app_name"],
                    PROFILES[profile]["app_name"],
                )
                self.assertEqual(
                    launch.settings["newrelic"]["collector_ip"],
                    profiles[profile]["collector_ip"],
                )

    def test_stg_and_prd_reject_development_collector_and_app_overrides(self):
        for profile in ("stg", "STG", "prd", "PRD"):
            for overrides in (
                {"DETECTOR_COLLECTOR_IP": "30.171.36.66"},
                {
                    "DETECTOR_COLLECTOR_IP": "192.0.2.30",
                    "NEW_RELIC_APP_NAME": "sec-know-celery-dev",
                },
            ):
                with (
                    self.subTest(profile=profile, overrides=overrides),
                    self.assertRaises(ValueError),
                ):
                    self.build(
                        environ={**self.environ, "env_profile": profile, **overrides}
                    )

    def test_collector_override_can_complete_closed_profile_without_mutating_template(
        self,
    ):
        launch = self.build(
            environ={
                **self.environ,
                "env_profile": "stg",
                "DETECTOR_COLLECTOR_IP": "192.0.2.30",
            }
        )
        self.assertEqual(launch.settings["newrelic"]["collector_ip"], "192.0.2.30")
        self.assertEqual(
            json.loads(self.profile_file.read_text(encoding="utf-8")), PROFILES
        )

    def test_ids_are_stable_short_and_distinct_across_workers_hosts_and_profiles(self):
        first = self.build()
        self.assertEqual(first.agent_id, self.build().agent_id)
        self.assertEqual(first.config_path, self.build().config_path)
        launches = [self.build(worker) for worker in QUEUES]
        launches.append(
            self.build(environ={**self.environ, "DETECTOR_INSTANCE_ID": "other-host"})
        )
        launches.append(
            self.build(
                environ={
                    **self.environ,
                    "env_profile": "stg",
                    "DETECTOR_COLLECTOR_IP": "192.0.2.30",
                }
            )
        )
        self.assertEqual(len({launch.agent_id for launch in launches}), len(launches))
        for launch in launches:
            self.assertLessEqual(len(launch.agent_id), 24)
            self.assertRegex(launch.agent_id, r"^[A-Za-z0-9_-]+$")

    def test_default_instance_is_hostname_without_dns_lookup(self):
        env = {"env_profile": "local"}
        with (
            mock.patch("socket.gethostname", return_value="host-name.fixture"),
            mock.patch(
                "socket.gethostbyname", side_effect=AssertionError("DNS lookup")
            ),
        ):
            launch = self.build(environ=env)
        explicit = self.build(
            environ={**env, "DETECTOR_INSTANCE_ID": "host-name.fixture"}
        )
        self.assertEqual(launch.agent_id, explicit.agent_id)

    def test_sdk_and_runtime_directory_overrides_accept_spaces(self):
        other_sdk = self.root / "alternate sdk"
        self.sdk.rename(other_sdk)
        runtime = self.root / "runtime ini directory"
        launch = self.build(
            environ={
                **self.environ,
                "DETECTOR_AGENT_HOME": str(other_sdk),
                "DETECTOR_RUNTIME_DIR": str(runtime),
            }
        )
        self.assertEqual(launch.sdk, other_sdk)
        self.assertTrue(launch.config_path.is_relative_to(runtime))
        self.assertEqual(launch.command[1], str(other_sdk / "detector-admin"))
        self.assertFalse(runtime.exists())

    def test_worker_queue_spellings_preserve_original_arguments(self):
        for worker, queue in QUEUES.items():
            for queue_args in (
                ["-Q", queue],
                ["--queues", queue],
                [f"--queues={queue}"],
            ):
                with self.subTest(worker=worker, queue_args=queue_args):
                    args = [
                        "-A",
                        "fake_business.celery_app",
                        "worker",
                        *queue_args,
                        "-n",
                        "worker@%%h",
                    ]
                    self.assertEqual(self.build(worker, args=args).command[6:], args)

    def test_missing_wrong_multi_and_repeated_queues_are_rejected(self):
        bad_queue_args = (
            [],
            ["-Q"],
            ["-Q", QUEUES["v4"]],
            ["-Q", f"{QUEUES['v32']},{QUEUES['v4']}"],
            ["-Q", QUEUES["v32"], "-Q", QUEUES["v32"]],
            ["-Q", QUEUES["v32"], f"--queues={QUEUES['v32']}"],
            [f"--queues={QUEUES['v32']}", f"--queues={QUEUES['v32']}"],
        )
        for queue_args in bad_queue_args:
            with self.subTest(queue_args=queue_args), self.assertRaises(ValueError):
                self.build(
                    args=["-A", "fake_business.celery_app", "worker", *queue_args]
                )

    def test_nonworkers_embedded_beat_and_daemonization_are_rejected(self):
        rejected = (
            ["-A", "fake_business.celery_app", "beat", "-Q", QUEUES["v32"]],
            ["-A", "fake_business.celery_app", "flower", "-Q", QUEUES["v32"]],
            ["-A", "fake_business.celery_app", "-Q", QUEUES["v32"]],
            [*self.args(), "-B"],
            [*self.args(), "--beat"],
            [*self.args(), "--detach"],
            [*self.args(), "-D"],
        )
        for args in rejected:
            with self.subTest(args=args), self.assertRaises(ValueError):
                self.build(args=args)
        with self.assertRaises(ValueError):
            self.build("unknown", args=self.args())

    def test_write_settings_is_private_and_reuses_one_stable_path(self):
        launch = self.build()
        launcher.write_settings(launch)
        self.assertEqual(stat.S_IMODE(launch.config_path.stat().st_mode), 0o600)
        parsed = configparser.ConfigParser(interpolation=None)
        parsed.read(launch.config_path, encoding="utf-8")
        self.assertEqual(
            parsed["newrelic"]["license_key"], "fixture-private-license-100%only"
        )
        self.assertEqual(parsed["newrelic"]["log_file"], "stdout")
        launch.config_path.chmod(0o644)
        launcher.write_settings(launch)
        self.assertEqual(stat.S_IMODE(launch.config_path.stat().st_mode), 0o600)
        self.assertEqual(
            list(launch.config_path.parent.glob("*.ini")), [launch.config_path]
        )
        self.assertEqual(self.base_ini.read_text(encoding="utf-8"), BASE_INI)

    def test_failed_replace_keeps_last_config_and_cleans_temporary_secret_file(self):
        launch = self.build()
        launcher.write_settings(launch)
        previous = launch.config_path.read_bytes()
        launch.settings["newrelic"]["app_name"] = "changed-app"
        with mock.patch.object(
            launcher.os, "replace", side_effect=OSError("fixture failure")
        ):
            with self.assertRaises(OSError):
                launcher.write_settings(launch)
        self.assertEqual(launch.config_path.read_bytes(), previous)
        self.assertEqual(
            list(launch.config_path.parent.iterdir()), [launch.config_path]
        )

    def install_fake_commands(self):
        script = self.root / "scripts" / "detector_worker.py"
        script.parent.mkdir(parents=True)
        shutil.copyfile(SOURCE, script)
        report = self.root / "fake-exec-report.json"
        (self.sdk / "detector-admin").write_text(
            "import json, os, pathlib, sys\n"
            "assert sys.argv[1] == 'run-program'\n"
            "pathlib.Path(os.environ['FAKE_EXEC_REPORT']).write_text(\n"
            "    json.dumps({'admin_pid': os.getpid()}), encoding='utf-8')\n"
            "os.execvpe(sys.argv[2], sys.argv[2:], os.environ)\n",
            encoding="utf-8",
        )
        celery = self.root / "celery"
        celery.mkdir()
        (celery / "__init__.py").write_text("", encoding="utf-8")
        (celery / "__main__.py").write_text(
            "import json, os, pathlib, sys\n"
            "path = pathlib.Path(os.environ['FAKE_EXEC_REPORT'])\n"
            "report = json.loads(path.read_text(encoding='utf-8'))\n"
            "report.update(celery_pid=os.getpid(), cwd=os.getcwd(), argv=sys.argv[1:], env=dict(os.environ))\n"
            "path.write_text(json.dumps(report), encoding='utf-8')\n",
            encoding="utf-8",
        )
        env = os.environ.copy()
        for key in POLLUTED_VARIABLES + (
            "DETECTOR_AGENT_HOME",
            "DETECTOR_RUNTIME_DIR",
            "NEW_RELIC_CONFIG_FILE",
            "NEW_RELIC_K8S_OPERATOR_ENABLED",
            "NEW_RELIC_AZURE_OPERATOR_ENABLED",
            "PYTHONPATH",
        ):
            env.pop(key, None)
        env.update(self.environ)
        env["FAKE_EXEC_REPORT"] = str(report)
        env["BUSINESS_SETTING"] = "preserved-in-child"
        return script, report, env

    def test_operator_conflict_stops_cli_before_config_write_or_exec(self):
        script, report_path, env = self.install_fake_commands()
        for variable in (
            "NEW_RELIC_K8S_OPERATOR_ENABLED",
            "NEW_RELIC_AZURE_OPERATOR_ENABLED",
        ):
            for check in ([], ["--check"]):
                with self.subTest(variable=variable, check=check):
                    result = subprocess.run(
                        [
                            sys.executable,
                            str(script),
                            "v32",
                            *check,
                            "--",
                            *self.args(),
                        ],
                        cwd=self.root.parent,
                        env={**env, variable: "true"},
                        capture_output=True,
                        text=True,
                        timeout=10,
                        check=False,
                    )
                    self.assertEqual(result.returncode, 2)
                    self.assertIn(variable, result.stderr)
                    self.assertIn("conflicts", result.stderr)
                    self.assertNotIn("Traceback", result.stderr)
                    self.assertFalse(report_path.exists())
                    self.assertFalse((self.root / "nas").exists())

    def test_real_cli_exec_chain_preserves_pid_cwd_and_every_celery_argument(self):
        script, report_path, env = self.install_fake_commands()
        env["NEW_RELIC_ENVIRONMENT"] = "production"
        env["NEW_RELIC_LOG"] = "/tmp/unwanted-file.log"
        args = self.args()
        process = subprocess.Popen(
            [sys.executable, str(script), "v32", "--", *args],
            cwd=self.root.parent,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        try:
            stdout, stderr = process.communicate(timeout=10)
        finally:
            if process.poll() is None:
                process.kill()
                process.communicate()
        self.assertEqual(process.returncode, 0, msg=stdout + stderr)
        report = json.loads(report_path.read_text(encoding="utf-8"))
        self.assertEqual(report["admin_pid"], process.pid)
        self.assertEqual(report["celery_pid"], process.pid)
        self.assertEqual(report["cwd"], str(self.root))
        self.assertEqual(report["argv"], args)
        self.assertEqual(report["env"]["BUSINESS_SETTING"], "preserved-in-child")
        self.assertEqual(report["env"]["env_profile"], "local")
        for variable in POLLUTED_VARIABLES:
            self.assertNotIn(variable, report["env"])
        config = Path(report["env"]["NEW_RELIC_CONFIG_FILE"])
        self.assertEqual(stat.S_IMODE(config.stat().st_mode), 0o600)

    def test_check_is_read_only_does_not_execute_or_print_config_and_broker_secrets(
        self,
    ):
        script, report_path, env = self.install_fake_commands()
        args = [
            "--broker",
            "redis://fixture-user:fixture-broker-secret@localhost/1",
            *self.args(),
        ]
        for prefix in (["--check", "v32"], ["v32", "--check"]):
            with self.subTest(prefix=prefix):
                result = subprocess.run(
                    [sys.executable, str(script), *prefix, "--", *args],
                    cwd=self.root.parent,
                    env=env,
                    capture_output=True,
                    text=True,
                    timeout=10,
                    check=False,
                )
                self.assertEqual(
                    result.returncode, 0, msg=result.stdout + result.stderr
                )
                self.assertIn("local", result.stdout)
                self.assertIn("v32", result.stdout)
                self.assertNotIn(
                    "fixture-private-license", result.stdout + result.stderr
                )
                self.assertNotIn("fixture-broker-secret", result.stdout + result.stderr)
                self.assertFalse(report_path.exists())
                self.assertFalse((self.root / "nas").exists())

    def test_bad_ini_and_profiles_fail_without_executing_or_printing_secret_contents(
        self,
    ):
        script, report_path, env = self.install_fake_commands()
        cases = (
            (self.base_ini, "fixture-private-ini-content-without-section\n"),
            (self.profile_file, '{"local": fixture-private-json-content}'),
        )
        for path, malformed in cases:
            with self.subTest(path=path.name):
                original = path.read_text(encoding="utf-8")
                path.write_text(malformed, encoding="utf-8")
                try:
                    result = subprocess.run(
                        [sys.executable, str(script), "v32", "--", *self.args()],
                        cwd=self.root.parent,
                        env=env,
                        capture_output=True,
                        text=True,
                        timeout=10,
                        check=False,
                    )
                finally:
                    path.write_text(original, encoding="utf-8")
                self.assertEqual(result.returncode, 2)
                self.assertNotIn("fixture-private", result.stdout + result.stderr)
                self.assertNotIn("Traceback", result.stderr)
                self.assertFalse(report_path.exists())
                self.assertFalse((self.root / "nas").exists())


if __name__ == "__main__":
    unittest.main()
