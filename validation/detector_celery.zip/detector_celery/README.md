# Detector 接入工具

直接压缩整个 `detector_celery` 文件夹传到内网。原准备工具和 STG / PRD 配置已放在一起。

## 内网使用

1. 解压到用户主目录，得到 `~/detector_celery/prepare.py`。
2. 在终端执行以下命令，准备 STG / PRD 所需文件：

```bash
"$HOME/sec_know_model/.venv/bin/python" "$HOME/detector_celery/prepare.py" \
  --root "$HOME/sec_know_model" --target supervisor
```

项目不在 `~/sec_know_model` 时，把命令中的项目路径换成实际位置。该步骤生成候选配置，保留原 Supervisor 文件和已有环境配置，不启动服务。

3. 在项目 `config/detector/profiles.json` 中填写运维确认的 STG / PRD Collector 地址；随后按 [STG / PRD 操作说明](stg_prd_handoff/README.md#1-填写环境配置) 继续设置采集、检查和发布。

厂商 SDK 使用内网维护方确认的 Linux 版本。本目录提供接入工具和配置模板，不含厂商 SDK。

## 目录

- `prepare.py`：准备工具，沿用 23 号 r2 版本。
- `files/`：工具安装到业务项目的 worker wrapper 和环境模板。
- `stg_prd_handoff/`：STG / PRD 配置片段及详细说明。
- `test_prepare.py`、`test_detector_worker.py`：离线工具测试。
