#!/usr/bin/env python3
"""Start one existing Celery worker with the operator-provided Detector SDK.

This standalone file is copied into sec_know_model/scripts. It imports neither
the application nor the SDK before handing off to detector-admin run-program.
"""

from __future__ import annotations

import argparse
import configparser
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import sys
import tempfile
from typing import Mapping


WORKERS = {
    "v32": "DeepSeek_V32_queue",
    "v4": "DeepSeek_V4_Flash_My_queue",
    "pub": "Pub_DeepSeek_V4_Flash_queue",
}
PROFILES = {"local", "stg", "prd"}
DEV_COLLECTOR = "30.171.36.66"


@dataclass
class Launch:
    profile: str
    worker: str
    sdk: Path
    config_path: Path
    settings: configparser.ConfigParser
    command: list[str]
    env: dict[str, str]
    agent_id: str


def _path(root: Path, environ: Mapping[str, str], name: str, default: Path) -> Path:
    if name not in environ:
        return default
    value = environ[name].strip()
    if not value:
        raise ValueError(f"{name} must not be empty")
    path = Path(value).expanduser()
    return path if path.is_absolute() else root / path


def _validate_worker(worker: str, args: list[str]) -> None:
    if worker not in WORKERS:
        raise ValueError("worker must be v32, v4 or pub")
    if "worker" not in args or any(
        arg in {"beat", "flower", "-B", "--beat", "-D", "--detach"} for arg in args
    ):
        raise ValueError("only a foreground Celery worker is supported")
    queues = []
    for index, arg in enumerate(args):
        if arg in {"-Q", "--queues"}:
            if index + 1 >= len(args):
                raise ValueError("Celery queue option has no value")
            queues.append(args[index + 1])
        elif arg.startswith("--queues="):
            queues.append(arg.split("=", 1)[1])
        elif arg.startswith("-Q") and len(arg) > 2:
            queues.append(arg[2:])
    if queues != [WORKERS[worker]]:
        raise ValueError(
            f"worker {worker} requires exactly one queue: {WORKERS[worker]}"
        )


def _text(value: object, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"configure {label} for the selected environment")
    value = value.strip()
    if any(ord(char) < 32 or ord(char) == 127 for char in value):
        raise ValueError(f"{label} contains control characters")
    return value


def _validate_bootstrap_environment(
    root: Path, sdk: Path, environ: Mapping[str, str]
) -> None:
    for variable in (
        "NEW_RELIC_K8S_OPERATOR_ENABLED",
        "NEW_RELIC_AZURE_OPERATOR_ENABLED",
    ):
        # Match the vendor bootstrap exactly: it lowercases without stripping.
        if environ.get(variable, "off").lower() in {"on", "true", "1"}:
            raise ValueError(
                f"{variable} conflicts with this manual SDK launcher; "
                "resolve the operator injection before using this launcher"
            )
    bootstrap = (sdk / "newrelic/bootstrap").resolve()
    for entry in environ.get("PYTHONPATH", "").split(os.pathsep):
        if not entry:
            continue
        path = Path(entry)
        # run-program executes after chdir(root), including relative path items.
        path = path if path.is_absolute() else root / path
        if path.resolve() == bootstrap:
            raise ValueError(
                "PYTHONPATH already contains this SDK bootstrap; remove the "
                "inherited bootstrap entry before using this launcher"
            )


def build_launch(
    root: Path, worker: str, celery_args: list[str], environ: Mapping[str, str]
) -> Launch:
    """Validate configuration and construct a launch without any writes/network."""
    root = root.resolve()
    # root_config derives ENV from env_profile.upper(). Use the same selector
    # case-insensitively without importing business configuration (which may
    # fetch credentials), and retain its original value in the child environment.
    profile = environ.get("env_profile", "").lower()
    if profile not in PROFILES:
        raise ValueError(
            "set env_profile explicitly to LOCAL, STG or PRD (case-insensitive)"
        )
    _validate_worker(worker, celery_args)

    sdk = _path(
        root, environ, "DETECTOR_AGENT_HOME", root / "detector-python-agent-v3.2.3"
    )
    _validate_bootstrap_environment(root, sdk, environ)
    if not (sdk / "detector-admin").is_file() or not (sdk / "newrelic").is_dir():
        raise ValueError(
            "Detector SDK is missing; install it in the project or set DETECTOR_AGENT_HOME"
        )
    profiles_path = _path(
        root, environ, "DETECTOR_PROFILES_FILE", root / "config/detector/profiles.json"
    )
    profiles = json.loads(profiles_path.read_text(encoding="utf-8"))
    if not isinstance(profiles, dict) or not isinstance(profiles.get(profile), dict):
        raise ValueError(
            "profiles.json must contain an object for the selected environment"
        )
    selected = profiles[profile]
    app_name = _text(
        environ.get("NEW_RELIC_APP_NAME", selected.get("app_name")), "app_name"
    )
    collector = _text(
        environ.get("DETECTOR_COLLECTOR_IP", selected.get("collector_ip")),
        "collector_ip",
    )
    if len(app_name) > 24:
        raise ValueError("app_name must be at most 24 characters")
    if len(collector) > 253 or not re.fullmatch(
        r"[a-zA-Z0-9]+(?:[a-zA-Z0-9.-]*[a-zA-Z0-9])?", collector
    ):
        raise ValueError(
            "collector_ip must be a host name or IPv4 address without a scheme/port"
        )
    if collector.lower() in {"changeme", "todo", "localhost", "0.0.0.0", "127.0.0.1"}:
        raise ValueError("configure the real Collector address")
    if profile != "local" and (
        collector == DEV_COLLECTOR or app_name == "sec-know-celery-dev"
    ):
        raise ValueError(
            "STG/PRD must not use the Mac DEV Collector or application name"
        )

    instance = _text(
        environ.get("DETECTOR_INSTANCE_ID", socket.gethostname()),
        "DETECTOR_INSTANCE_ID",
    )
    digest = hashlib.sha256(f"{profile}\0{instance}\0{worker}".encode()).hexdigest()[
        :16
    ]
    agent_id = f"sk-{worker}-{digest}"
    runtime = _path(root, environ, "DETECTOR_RUNTIME_DIR", root / "nas/data/detector")
    config_path = runtime / profile / f"{agent_id}.ini"

    settings = configparser.ConfigParser(interpolation=None)
    with (sdk / "detector.ini").open(encoding="utf-8-sig") as stream:
        settings.read_file(stream)
    if not settings.has_section("newrelic"):
        raise ValueError("the SDK detector.ini must contain [newrelic]")
    settings["newrelic"].update(
        {
            "app_name": app_name,
            "agent_id": agent_id,
            "collector_ip": collector,
            "log_file": "stdout",
            "log_level": "info",
        }
    )
    env = dict(environ)
    # Validated values live in the generated base section. An inherited SDK
    # environment section or log override must not select a different target.
    for key in (
        "NEW_RELIC_ENVIRONMENT",
        "NEW_RELIC_APP_NAME",
        "DETECTOR_AGENT_ID",
        "DETECTOR_COLLECTOR_IP",
        "NEW_RELIC_LOG",
        "NEW_RELIC_LOG_LEVEL",
    ):
        env.pop(key, None)
    env["NEW_RELIC_CONFIG_FILE"] = str(config_path)
    command = [
        sys.executable,
        str(sdk / "detector-admin"),
        "run-program",
        sys.executable,
        "-m",
        "celery",
        *celery_args,
    ]
    return Launch(profile, worker, sdk, config_path, settings, command, env, agent_id)


def write_settings(launch: Launch) -> None:
    """Replace a stable private ini; repeated starts do not accumulate files."""
    launch.config_path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=launch.config_path.parent, delete=False
        ) as stream:
            temporary = Path(stream.name)
            os.fchmod(stream.fileno(), 0o600)
            launch.settings.write(stream)
        os.replace(temporary, launch.config_path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("worker", choices=WORKERS)
    parser.add_argument(
        "--check",
        action="store_true",
        help="validate paths/config only; no SDK, network, writes or worker startup",
    )
    if "--" not in argv:
        parser.error("separate the original Celery arguments with --")
    split = argv.index("--")
    options = parser.parse_args(argv[:split])
    root = Path(__file__).resolve().parents[1]
    try:
        launch = build_launch(root, options.worker, argv[split + 1 :], os.environ)
        summary = {
            "mode": "check_only" if options.check else "starting",
            "profile": launch.profile,
            "worker": launch.worker,
            "sdk": str(launch.sdk),
            "python": sys.executable,
            "config_path": str(launch.config_path),
            "app_name": launch.settings["newrelic"]["app_name"],
            "collector_ip": launch.settings["newrelic"]["collector_ip"],
            "agent_id": launch.agent_id,
            "log_file": "stdout",
        }
        if options.check:
            print(json.dumps(summary, ensure_ascii=False))
            return 0
        write_settings(launch)
        print(json.dumps(summary, ensure_ascii=False), flush=True)
        os.chdir(root)
        os.execvpe(launch.command[0], launch.command, launch.env)
    except (OSError, ValueError, configparser.Error) as exc:
        # Do not dump an ini parse error (it may contain private SDK settings).
        detail = (
            str(exc)
            if isinstance(exc, ValueError) and not isinstance(exc, json.JSONDecodeError)
            else type(exc).__name__
        )
        print(f"Detector startup stopped: {detail}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
